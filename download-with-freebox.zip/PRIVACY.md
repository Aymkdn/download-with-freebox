# Règles de confidentialité

Aucune information n'est collectée. Tout reste en local, entre vous et votre Freebox.
